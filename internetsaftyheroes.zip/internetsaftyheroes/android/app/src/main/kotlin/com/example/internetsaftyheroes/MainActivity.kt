package com.example.internetsaftyheroes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
